import React from 'react';
import Details from '../components/About/Details';

const About = () => {
  return (
    <main>
      <Details />
    </main>
  );
};

export default About;